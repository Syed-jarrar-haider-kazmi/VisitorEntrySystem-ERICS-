package com.example.erics;

public class user {

    String roll_number, dept, imp_path, name, batch, campus,leaveTime,joinTime ;

    public String getWrongActivity() {
        return wrongActivity;
    }

    String  wrongActivity;


    public String getRoll_number() {
        return roll_number;
    }

    public String getDept() {
        return dept;
    }

    public String getImp_path() {
        return imp_path;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBatch() {
        return batch;
    }



    public String getCampus() {
        return campus;
    }



    public String getLeaveTime() {
        return leaveTime;
    }


    public String getJoinTime() {
        return joinTime;
    }




}
