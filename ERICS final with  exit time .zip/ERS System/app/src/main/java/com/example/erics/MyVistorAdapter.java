package com.example.erics;

import static android.content.ContentValues.TAG;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


public class MyVistorAdapter extends RecyclerView.Adapter<MyVistorAdapter.MyviewHolder> {//implements  Filterable{
    Button cancel;
    user u;

    DatabaseReference ref;
    List<user> Vlist;
    //List<user> filter;
    Context context;

    public MyVistorAdapter(Context context, List<user> vlist, DatabaseReference r) {
        Vlist = vlist;
        //filter=Vlist;
        this.context = context;
        this.ref = r;
    }

    @NonNull
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.contact_list_layout, parent, false);

        return new MyviewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyviewHolder holder, final int position) {
        u = Vlist.get(position);
        holder.name.setText(u.getName());

    }

    @Override
    public int getItemCount() {
        return Vlist.size();
    }

//    @Override
//    public Filter getFilter() {
//        return filter;
//    }
//
//    Filter filter = new Filter() {
//        @Override
//        protected FilterResults performFiltering(CharSequence charSequence) {
//
//            List<String> filtering =new ArrayList<>();
//            if(charSequence.toString().isEmpty())
//            {
//                filtering.addAll(data);
//            }else{
//                for(String name : filters)
//                {
//                    if (name.toLowerCase().contains(charSequence.toString().toLowerCase())){
//                        filtering.add(name);
//                    }
//                }
//
//            }
//FilterResults filterResults = new FilterResults();
//            filterResults.values=filtering;
//            return filterResults;
//
//        }
//
//        @Override
//        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
//
//    data.clear();
//    data.addAll((Collection <? extends  String>)filterResults.values);
//   notifyDataSetChanged();
//        }
//    };

    public class MyviewHolder extends RecyclerView.ViewHolder {

        ImageView imgcontact;
        TextView name, No, mail;
        int a;

        public MyviewHolder(@NonNull View itemView) {
            super(itemView);

            imgcontact = itemView.findViewById(R.id.ImgContact);
            name = itemView.findViewById(R.id.contacts);

            final String val;
            itemView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    a = getAdapterPosition();
                    // getting the position of the selected contact
                    Intent ints = new Intent(v.getContext(), VisitorDescription.class);

                    //Getting the Selected position and accessing particular data
                    ints.putExtra("name", Vlist.get(a).getName());  // sending the particular data of Visitor
                    ints.putExtra("roll", Vlist.get(a).getRoll_number());
                    ints.putExtra("dep", Vlist.get(a).getDept());
                    ints.putExtra("fault", Vlist.get(a).getWrongActivity());
                    ints.putExtra("img", Vlist.get(a).getImp_path());

                    Log.d(TAG, "onClick faulty............................: "+Vlist.get(a).getWrongActivity());
                    ints.putExtra("jtime", Vlist.get(a).getJoinTime());
                    ints.putExtra("ltime", Vlist.get(a).getLeaveTime());
                    ints.putExtra("batch", Vlist.get(a).getBatch());
                    ints.putExtra("campus", Vlist.get(a).getCampus());

                    v.getContext().startActivity(ints);

                }
            });

            //Deleting the Visitor record

            ImageButton cancel = (ImageButton) itemView.findViewById(R.id.deletes);
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //ref = FirebaseDatabase.getInstance().getReference("users").child(Vlist.get(a).getRoll_number());
                    // ref.removeValue();
                    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT+5:00"));
                    Date currentLocalTime = cal.getTime();
                    DateFormat date = new SimpleDateFormat("HH:mm:ss a");
// you can get seconds by adding  "...:ss" to it
                    date.setTimeZone(TimeZone.getTimeZone("GMT+1:00"));
                    FirebaseDatabase.getInstance().getReference("users").child(Vlist.get(a).getRoll_number()).child("leaveTime").setValue(date.format(currentLocalTime));

                    Log.d(TAG, "onClick: hello");
                }
            });
        }
    }
}




