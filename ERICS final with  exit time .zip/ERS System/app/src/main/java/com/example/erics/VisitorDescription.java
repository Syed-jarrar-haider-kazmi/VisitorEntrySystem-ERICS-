package com.example.erics;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class VisitorDescription extends AppCompatActivity {

    private static final String TAG = ":)";
    TextView name, rollnos, dep, jotimes, letimes, vbatchs, vcampuss,imgpaths;
    ImageView Pic;
    boolean msg;
    Switch falut;
    DatabaseReference databaseReference;

    //Globel Variables for Intend
    String vname, vroll,deps , jtime,ltime,batch, campus ,imgpath;
    String  faulty;

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_description);
        name = findViewById(R.id.name);
        rollnos = findViewById(R.id.rollno);
        dep = findViewById(R.id.department);
        falut = findViewById(R.id.faulty);
        jotimes =findViewById(R.id.jtime);
        letimes =findViewById(R.id.ltime);
        vbatchs =findViewById(R.id.batch);
        vcampuss =findViewById(R.id.scampus);
        Pic = findViewById(R.id.Imgcontant4);
        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        setTitle("Entry System");


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // getting the intend call
        Intent i = getIntent();




        vname= i.getStringExtra("name");
        name.setText("" + vname);

        vroll = i.getStringExtra("roll");
        rollnos.setText("" + vroll);

        deps = i.getStringExtra("dep");
        dep.setText("" + deps);

        imgpath=i.getStringExtra("img");  // now setting the image path latter on will set

        faulty = i.getStringExtra("fault");
        Log.d("faulty State on intent=======================================================", "" + faulty);

//            Toast.makeText(this,faulty,Toast.LENGTH_SHORT).show();
            if(faulty.contains("true")) {
                falut.setChecked(true);
            }


        jtime=i.getStringExtra("jtime");
        jotimes.setText("JoinTime : "+jtime);

        ltime=i.getStringExtra("ltime");
        letimes.setText("LeaveTime : "+ltime);

        batch=i.getStringExtra("batch");
        vbatchs.setText("Batch : "+batch);

        campus=i.getStringExtra("campus");
        vcampuss.setText("Campus : "+campus);


        Pic.setImageResource(R.drawable.contact_pic); // setting default image resource

        // setting on click listener on switch

        falut.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (falut.isChecked()) {

                    databaseReference.child(vroll).child("wrongActivity").setValue("true");
                    Log.v("Switch State on true=", "" + falut.isChecked());
                } else {
                    databaseReference.child(vroll).child("wrongActivity").setValue("false");
                    Log.v("Switch State on false =", "" + falut.isChecked());
                }
            }
        });
    }
}
