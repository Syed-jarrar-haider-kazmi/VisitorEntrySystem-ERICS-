package com.example.erics;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseReference databaseReference;   // declaring database refrence object
    ArrayList<user> arrayList;            //
    RecyclerView Vistor;
    MyVistorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




            Vistor = findViewById(R.id.contacts);
            Vistor.setHasFixedSize(true);  // setting recycler view of fixed size
            // binding the firebase with the reference "user"
            databaseReference = FirebaseDatabase.getInstance().getReference("users");

            Vistor.setLayoutManager(new LinearLayoutManager(this));
            arrayList = new ArrayList<>();  // initializing array list on which data will be Mapped

            //Some testing Data below
    //            user u =new user();
    //            u.setImage("ING");
    //            u.setName("Jarar");
    //            u.setID("10101");
    //            u.setDepartment("BSCS");

            //   arrayList.add(0,u);

            adapter = new MyVistorAdapter(this, arrayList, databaseReference);
            Vistor.setAdapter(adapter);   // setting adapter by setting reference and context

            //Getting the values from the Firebase and getting data snap shot

            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    arrayList.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        user users = dataSnapshot.getValue(user.class);
                        Log.d(TAG, "onDataChange...............................................................: users");

                        arrayList.add(users);
                    }
                    adapter.notifyDataSetChanged();

                }


                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }

    //            @Override
    //            public boolean onCreateOptionsMenu(Menu menu) {
    //                getMenuInflater().inflate(R.menu.searchs,menu);
    //                MenuItem item = menu.findItem(R.id.searches);
    //                SearchView searchView =(SearchView) item .getActionView();
    //                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
    //                    @Override
    //                    public boolean onQueryTextSubmit(String query) {
    //
    //                        return false;
    //                    }
    //
    //                    @Override
    //                    public boolean onQueryTextChange(String s) {
    //
    //                       adapter.getFilter().filter(s);
    //                       return  false;
    //                    }
    //                });
    //                return super.onCreateOptionsMenu(menu);
    //            }
    }
